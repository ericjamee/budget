#!/usr/bin/env bash
# Place in .platform/hooks/postdeploy directory
sudo certbot -n -d nestegg.is404.net --nginx --agree-tos --email samrichey01@gmail.com