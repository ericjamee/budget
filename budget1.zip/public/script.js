function addCategory() {
    const newCategory = document.getElementById('add-category').value;
    if (newCategory) {
      const select = document.getElementById('delete-category');
      const option = document.createElement('option');
      option.value = newCategory;
      option.textContent = newCategory;
      select.appendChild(option);
      document.getElementById('add-category').value = '';
      alert("Category added!");
    }
  }
  
  function deleteCategory() {
    const select = document.getElementById('delete-category');
    if (select.value) {
      select.remove(select.selectedIndex);
      alert("Category deleted!");
    } else {
      alert("Please select a category to delete.");
    }
  }
  
